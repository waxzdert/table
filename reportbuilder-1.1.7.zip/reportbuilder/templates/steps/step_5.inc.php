<div class="row wdt-rb-step hidden" data-step="5">

    <div class="col-sm-12 col-md-12 wdt-rb-shortcodes-block">

    </div>

</div>