<div class="wpDataTableFilterSection" id="wdt-pf-search-filters-button-block">
    <button class="button btn wdt-pf-search-filters-button" <?php if ($disableSearchFiltersButton) {?>  disabled="disabled"<?php } ?>><?php _e(' Search', 'wpdatatables'); ?></button>
</div>