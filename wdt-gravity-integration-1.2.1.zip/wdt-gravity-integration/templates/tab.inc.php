<li class="gravity-settings-tab hidden">
    <a href="#gravity-settings" aria-controls="gravity-settings" role="tab"
       data-toggle="tab"><?php _e('Gravity Settings', 'wpdatatables'); ?></a>
</li>